﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using BankMangementBusiness;
using BankMangementMVC.Models;

namespace BankMangementMVC.Controllers;

public class HomeController : Controller
{
    private readonly ILogger<HomeController> _logger;
    private readonly IDatabase _Database;

    public HomeController(ILogger<HomeController> logger,IDatabase database)
    {
        _logger = logger;
        _Database=database;
    }

    public IActionResult Index()
    {
       if(HttpContext.Session.GetString("Username") == null)
        {
            ViewBag.Name =null;
            return View();
        }
        else
        {
            ViewBag.Name=HttpContext.Session.GetString("Username");
            return View();
        }
    }

    public IActionResult Privacy()
    {
            if(HttpContext.Session.GetString("Username") == null)
        {
            ViewBag.Name =null;
            return View();
        }
        else
        {
            ViewBag.Name=HttpContext.Session.GetString("Username");
            return View();
        }
    }
    public IActionResult About()
    {
       if(HttpContext.Session.GetString("Username") == null)
        {
            ViewBag.Name =null;
            return View();
        }
        else
        {
            ViewBag.Name=HttpContext.Session.GetString("Username");
            return View();
        }
    }
    [HttpGet]
    public IActionResult SignupBank()
    {
        if(HttpContext.Session.GetString("Username") == null)
        {
            ViewBag.Name =null;
            return View();
        }
        else
        {
            ViewBag.Name=HttpContext.Session.GetString("Username");
            return View();
        }
    }
    [HttpPost]  
    [ActionName("SignupBank")]
     public IActionResult SignupBank(Signup signup)
    {       
        //    _Database.DBConnectionString="server=localhost;user=root;database=blooddonor;port=3306;password=Aspire@123";
           //return Content(signup.NewUserName+" "+signup.NewPassword+" "+signup.PhoneNumber+" "+signup.EmailId+" "+signup.ReenterPassword);

        if(signup.NewUserName.Length !=0 && signup.NewPassword.Length !=0 && signup.PhoneNumber.Length !=0 && signup.ReenterPassword.Length !=0)
        {
            if(signup.NewPassword.Length <= 7)
            {
                ViewBag.PasswordError = "Password must be in 8 character";
                return View();
            }
            else
            {
                int SignupStaus=_Database.Signup(signup.NewUserName,signup.NewPassword,signup.PhoneNumber,signup.EmailId,signup.ReenterPassword);
                ViewBag.PasswordError = "";
                if(SignupStaus==1)
                {
                    HttpContext.Session.SetString("Username",signup.NewUserName);
                    return RedirectToAction("DonorDashboard","Home");

                }
                else if(SignupStaus==-1)
                {
                    ViewBag.Notification = "Renetered password and New password is not same";
                    return View();
                    
                }
                else{
                    ViewBag.Notification = "Username Already exist";
                    return View();
                }
            }
        }
        else
        {
            return View();
        }
    }
    public IActionResult SearchBank()
    {
        if(HttpContext.Session.GetString("Username") == null)
        {
            ViewBag.Name =null;
            return View();
        }
        else
        {
            ViewBag.Name=HttpContext.Session.GetString("Username");
            return View();
        }
    }


   [HttpGet]
    public IActionResult Login(){
        if(HttpContext.Session.GetString("Username") == null)
        {
            ViewBag.Name =null;
            return View();
        }
        else
        {
            ViewBag.Name=HttpContext.Session.GetString("Username");
            return View();
        }

    }
    [ActionName("Login")]
    [HttpPost]
    public IActionResult Login(Login login)
    {
        //_Database.DBConnectionString="server=localhost;user=root;database=blooddonor;port=3306;password=Aspire@123";
       bool LoginStaus=_Database.Login(login.Username,login.Password);

           if( login.Username !=null && login.Password !=null){
           if(LoginStaus)
           {
               HttpContext.Session.SetString("Username",login.Username);
               return RedirectToAction("BankDashboard","Home");

           }
           else{
               ViewBag.Notification = "Wrong Username Password";
               return View();
           }
        }
        else{
            return View();
        }
    }

    public IActionResult Logout()
    {
            HttpContext.Session.Clear();
            return RedirectToAction("Login","Home");
    }
     

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}