namespace BankManagementBusiness;

 public interface IDatabase
 {

  //  string DBConnectionString {set;}
    
  //Successfull login returns true else returns false   
  public bool Login(string Username,string Password);   
    
  //Returns 1 sucessfull signup
  //returns -1 if reneter password is not same as password
  //returns 0 for unsuccessfull signup when the username exist in database
  public int Signup(string NewUsername,string NewPassword,string PhoneNumber,string EmailId,string ReenterPassword); 

   }