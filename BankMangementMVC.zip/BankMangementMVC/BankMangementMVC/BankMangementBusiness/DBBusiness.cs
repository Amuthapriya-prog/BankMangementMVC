﻿using MySql.Data.MySqlClient;
using Serilog;
using System.Data;

namespace BankMangementBusiness;
public class DBBusiness:IDatabase
{
    public DBBusiness()
    {
        Log.Logger = new LoggerConfiguration()
                .MinimumLevel.Debug()
                .WriteTo.Console()
                .WriteTo.File("logs/myapp.txt", rollingInterval: RollingInterval.Day)
                .CreateLogger();
    }
    public bool Login(string Username,string Password)
    {
        MySqlConnection connection = new MySqlConnection();
           connection.ConnectionString = "server=localhost;user=root;database=bankdetails;port=3306;password=root";
           MySqlCommand commannd = new MySqlCommand(); 
            try
            {
                Console.WriteLine("Connecting to MySQL...");
                connection.Open();
                commannd.Connection = connection;

                commannd.CommandText = "Authentication";
                commannd.CommandType = CommandType.StoredProcedure;

                commannd.Parameters.AddWithValue("@InUsername", Username);
                commannd.Parameters["@InUsername"].Direction = ParameterDirection.Input;

                commannd.Parameters.AddWithValue("@InPassword", Password);
                commannd.Parameters["@InPassword"].Direction = ParameterDirection.Input;

                commannd.Parameters.Add("@Exist", MySqlDbType.VarChar);
                commannd.Parameters["@Exist"].Direction = ParameterDirection.Output;

                commannd.ExecuteNonQuery();
                if(commannd.Parameters["@Exist"].Value.ToString()=="Successfull"){
                    return true;
                }
                else{
                    return false;
                }
            }
             catch (MySqlException error)
            {
               Log.Error(error.ToString());
               return false;
            }
            finally{
                Log.CloseAndFlush();
                connection.Close();
            }
    }

    public int Signup(string NewUsername,string NewPassword,string PhoneNumber,string EmailId,string ReenterPassword)
    {
            MySqlConnection connection = new MySqlConnection();
            connection.ConnectionString ="server=localhost;user=root;database=bankdetails;port=3306;password=root";
            MySqlCommand commannd = new MySqlCommand(); 
            try
            {
                Console.WriteLine("Connecting to MySQL...");
                connection.Open();
                commannd.Connection = connection;

                commannd.CommandText = "Register";
                commannd.CommandType = CommandType.StoredProcedure;

                commannd.Parameters.AddWithValue("@NewUsern",NewUsername);
                commannd.Parameters["@NewUsern"].Direction = ParameterDirection.Input;

                commannd.Parameters.AddWithValue("@NewPass",NewPassword);
                commannd.Parameters["@NewPass"].Direction = ParameterDirection.Input;

                commannd.Parameters.AddWithValue("@NewPhno",PhoneNumber);
                commannd.Parameters["@NewPhno"].Direction = ParameterDirection.Input;

                commannd.Parameters.AddWithValue("@Email",EmailId);
                commannd.Parameters["@Email"].Direction = ParameterDirection.Input;

                commannd.Parameters.Add("@Success", MySqlDbType.VarChar);
                commannd.Parameters["@Success"].Direction = ParameterDirection.Output;

                if(NewPassword.Equals(ReenterPassword)){
                     commannd.ExecuteNonQuery();
                }
                else{
                    return -1;          //returs -1 if the reenter password and password is not same
                }
            
                if(commannd.Parameters["@Success"].Value.ToString()=="Account Created"){
                    Console.WriteLine("Account created successfully");
                    return 1;
                }
                else if(commannd.Parameters["@Success"].Value.ToString()=="Existing Username")
                {
                    return 0;          //returs 0 if the signup is unsuccessfull 
                }
            }
             catch (MySqlException error)
            {
               Log.Error(error.ToString());
               return 0;
            }
            finally{
                Log.CloseAndFlush();
                connection.Close();
            }
        return 0;
    }
}