using System.ComponentModel.DataAnnotations;
namespace BankMangementMVC.Models;

// The partial keyword indicates that other parts of the class, struct, or interface can be defined in the namespace.
public partial class Signup{

    [Required(ErrorMessage ="This field is required")]
    [DataType(DataType.Text)]
    public string NewUserName{get; set;}

    
    [DataType(DataType.EmailAddress)]
    [EmailAddress]
    public string EmailId {get;set;}


    [Required(ErrorMessage ="This field is required")]
    [Phone]
    [RegularExpression(@"^[6-9]{1}[0-9]{9}$",ErrorMessage = "Entered phone format is not valid.")]
    public string PhoneNumber {get;set;}


    [Required(ErrorMessage ="This field is required")]
    [DataType(DataType.Password)]
    [StringLength(255, MinimumLength = 8)]
    public string NewPassword{get;set;}

    [Required(ErrorMessage ="This field is required")]
    [Compare("NewPassword", ErrorMessage = "Password and Confirm Password do not match")]
    [DataType(DataType.Password)]
    public string ReenterPassword{get;set;}

}