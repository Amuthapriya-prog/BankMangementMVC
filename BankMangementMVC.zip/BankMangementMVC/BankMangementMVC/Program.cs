/* Title        : Bank Mangement MVC Application
   Author       : Amuthapriya M
   Created at   : 20.05.2022
*/


namespace BloodDonationMVC;
    class Program
    {
        static void Main(string[] args)
        {
            //Dependency injuction adding service
            Startup startup=new Startup();
            startup.Config(args);
        }
    }